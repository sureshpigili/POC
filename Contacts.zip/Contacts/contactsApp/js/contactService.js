var app = angular.module("contactServiceModule", ['ui.router', 'ui.bootstrap']);

app.service("contactsService",function ($http){
    
    this.getContactsList=function(){

        var promiseObj=$http.get("http://localhost:3000/contactsList");
        return promiseObj;
    }

    this.postContacts=function(addPerson){

        var postObj=$http.post("http://localhost:3000/addContact",addPerson);
        return postObj;

    }
    this.getContactsListById=function(id){

        var getObj=$http.get("http://localhost:3000/getContact?id="+id);
        return getObj;
    }

    this.putContacts=function(data){

        var putObj=$http.post("http://localhost:3000/updateContact",data);
        return putObj;
    }

    this.delContacts=function(id){

        var delObj=$http.post("http://localhost:3000/deleteContact",{"id":id});
        return delObj;
    }

});