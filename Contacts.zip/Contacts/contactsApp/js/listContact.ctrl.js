
// var contactsApp = angular.module("contactsApp", ['ui.router', 'ui.bootstrap','updateContactCtrl']);
var app = angular.module("listContactCtrlModule", ['ui.router', 'ui.bootstrap']);
app.controller("listContactCtrl",function($scope,$rootScope,contactsService) {
    // $state.go("home.listContact");
   /* $http.get("http://localhost:3000/contactsList").then(function(response) {
        $scope.contactList = response.data.contactList;
    })*/
    var httpPromiseObj=contactsService.getContactsList();
    httpPromiseObj.then(function(response){

         $scope.contactList = response.data.contactList;

    })


    $rootScope.$on("button clicked",function(){
        /*$http.get("http://localhost:3000/contactsList").then(function(response) {
            $scope.contactList = response.data.contactList;
        })*/
        var httpPromiseObj=contactsService.getContactsList();
        httpPromiseObj.then(function(response){

         $scope.contactList = response.data.contactList;

    })

    });
});
