var contactsApp = angular.module("contactsApp", ['ui.router', 'ui.bootstrap','listContactCtrlModule','addContactCtrlModule','updateContactCtrlModule','contactServiceModule']);

contactsApp.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/home/listContact');
    $stateProvider
        .state('home', {
            url: '/home',
            templateUrl: 'home.html',
            controller: 'addContactCtrl'
        })

    .state('home.addContact', {
            url: '/addContact',
            templateUrl: 'addContact.html',
            controller: 'addContactCtrl'
        })
        .state('home.listContact', {
            url: '/listContact',
            templateUrl: 'listContact.html',
            controller: 'listContactCtrl'

        })
        .state('home.updateContact', {
            url: '/updateContact',
            templateUrl: 'updateContact.html',
            controller: 'updateContactCtrl'

        })

}]);

// contactsApp.controller("addContactCtrl", function($scope, $state, $http,contactsService) {

//     $scope.saveContact = function() {

//         var addPerson = {

//             "firstName": $scope.firstName,
//             "lastName": $scope.lastName,
//             "email": $scope.email,
//             "phone": $scope.phone,
//             "work": $scope.work
//         }

//         console.log(JSON.stringify(addPerson));
//         // $http.get('../definitions/contactList.json',addPerson).then(function(response){
//         // 	$scope.contactList=[];
//         // 	$scope.contactList=response.data.contactList;
//         // 	$scope.contactList.push(JSON.stringify(addPerson));
//         // })
//         var postObj=contactsService.postContacts(addPerson);
//         postObj.then(function(response) {

//             console.log(JSON.stringify(response));
//             $state.go("home.listContact");
//         });

//     }

// });

/*contactsApp.controller("updateContactCtrl",function($scope,$http,$rootScope,$state,contactsService){
	$scope.getContact=function(id){*/
		/*var id = $stateParams.id ? $stateParams.id : 1;*/
		
		
		/*var baseUrl="http://localhost:3000/getContact?id="+id;*/
		/*var getObj=contactsService.getContactsListById(id);
		getObj.then(function(response){
			
			
			$rootScope.editcontact=response.data;
			console.log("getContact"+JSON.stringify(response));
			$state.go("home.updateContact");
		});
		
	}

	$scope.update=function(){

		var putObj=contactsService.putContacts($rootScope.editcontact);
        putObj.then(function(response){
			$state.go("home.listContact");
		})
		console.log($rootScope.editcontact);
	}

	$scope.deleteContact=function(id){*/
		/*var baseUrl="http://localhost:3000/deleteContact";
		console.log("id="+id);
		console.log(baseUrl);*/
        /*var confirmVal=confirm("Do you want to delete this Contact?");
        if(confirmVal){
            var delObj=contactsService.delContacts(id);

        delObj.then(function(response){
            
            alert("Deleted successfully");
            $rootScope.$broadcast("button clicked");
           
        });     

        } else{

             alert("Contact not deleted");
        }
		


            
		
	}
}); */
// contactsApp.controller("listContactCtrl",function($scope,$rootScope,contactsService) {
//     // $state.go("home.listContact");
//    /* $http.get("http://localhost:3000/contactsList").then(function(response) {
//         $scope.contactList = response.data.contactList;
//     })*/
//     var httpPromiseObj=contactsService.getContactsList();
//     httpPromiseObj.then(function(response){

//          $scope.contactList = response.data.contactList;

//     })


//     $rootScope.$on("button clicked",function(){
//         /*$http.get("http://localhost:3000/contactsList").then(function(response) {
//             $scope.contactList = response.data.contactList;
//         })*/
//         var httpPromiseObj=contactsService.getContactsList();
//         httpPromiseObj.then(function(response){

//          $scope.contactList = response.data.contactList;

//     })

//     });
// });

/*contactsApp.controller("deleteCntrl",function($scope,$http){


});*/
/*contactsApp.service("contactsService",function ($http){
    
    this.getContactsList=function(){

        var promiseObj=$http.get("http://localhost:3000/contactsList");
        return promiseObj;
    }

    this.postContacts=function(addPerson){

        var postObj=$http.post("http://localhost:3000/addContact",addPerson);
        return postObj;

    }
    this.getContactsListById=function(id){

        var getObj=$http.get("http://localhost:3000/getContact?id="+id);
        return getObj;
    }

    this.putContacts=function(data){

        var putObj=$http.post("http://localhost:3000/updateContact",data);
        return putObj;
    }

    this.delContacts=function(id){

        var delObj=$http.post("http://localhost:3000/deleteContact",{"id":id});
        return delObj;
    }

});*/
