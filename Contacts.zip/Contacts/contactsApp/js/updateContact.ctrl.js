var app = angular.module("updateContactCtrlModule", ['ui.router', 'ui.bootstrap']);
app.controller("updateContactCtrl",function($scope,$http,$rootScope,$state,contactsService){
	$scope.getContact=function(id){
		/*var id = $stateParams.id ? $stateParams.id : 1;*/
		
		
		/*var baseUrl="http://localhost:3000/getContact?id="+id;*/
		var getObj=contactsService.getContactsListById(id);
		getObj.then(function(response){
			
			
			$rootScope.editcontact=response.data;
			console.log("getContact"+JSON.stringify(response));
			$state.go("home.updateContact");
		});
		
	}

	$scope.update=function(){

		var putObj=contactsService.putContacts($rootScope.editcontact);
        putObj.then(function(response){
			$state.go("home.listContact");
		})
		console.log($rootScope.editcontact);
	}

	$scope.deleteContact=function(id){
		/*var baseUrl="http://localhost:3000/deleteContact";
		console.log("id="+id);
		console.log(baseUrl);*/
        var confirmVal=confirm("Do you want to delete this Contact?");
        if(confirmVal){
            var delObj=contactsService.delContacts(id);

        delObj.then(function(response){
            
            alert("Deleted successfully");
            $rootScope.$broadcast("button clicked");
           
        });     

        } else{

             alert("Contact not deleted");
        }
		


            
		
	}
}); 